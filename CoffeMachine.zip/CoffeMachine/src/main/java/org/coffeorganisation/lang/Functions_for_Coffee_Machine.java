package org.coffeorganisation.lang;


public interface Functions_for_Coffee_Machine {

    public String getCoffee();

}
package org.coffeorganisation.lang.impl;

import org.coffeorganisation.lang.Functions_for_Coffee_Machine;


public class Cappuchino implements Functions_for_Coffee_Machine {


    @Override
    public String getCoffee() {
        return "Cappuchino is ready! Warning - the cup is hot!";

    }
}
